package com.example.csl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CslApplicationTests {

	@Test
	void contextLoads() {
	}

}
