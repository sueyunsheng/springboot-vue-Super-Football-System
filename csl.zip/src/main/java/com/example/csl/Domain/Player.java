package com.example.csl.Domain;

import javax.persistence.*;
import lombok.*;

@Data
@Entity
@Table(name = "player")
public class Player {
    @Id
    @Column(name = "playerID",nullable = false)
    private String playerId;//球员编号

    @Column(name = "name",nullable = false)
    private String name;//姓名

    @Column(name = "IDnum",nullable = false)
    private String IDnum;//身份证号

    @Column(name = "birthday",nullable = false)
    private String birthday;//出生日期

    @Column(name = "origin",nullable = false)
    private String origin;//籍贯

    @Column(name = "height",nullable = false)
    private Integer height;//身高

    @Column(name = "weight",nullable = false)
    private Integer weight;//体重

    @Column(name = "shootnum",nullable = false)
    private Integer shootnum;//进球数

    @Column(name = "rednum",nullable = false)
    private Integer rednum;//红牌数

    @Column(name = "yelnum",nullable = false)
    private Integer yelnum;//黄牌数

    @Column(name = "position")
    private String position;//擅长位置

    @Column(name = "teamID")
    private String teamID;//球队编号

    @Column(name = "teamname")
    private String teamname;//球队名称

    public Player() {
        rednum = 0;
        yelnum = 0;
        shootnum = 0;
    }
}
