package com.example.csl.Domain;

import javax.persistence.*;
import lombok.*;

@Data
@Entity
@Table(name = "teamresult")
public class TeamResult {
    @Id
    @Column(name = "teamID",nullable = false)
    private String teamID;//球队编号

    @Column(name = "season",nullable = false)
    private Integer season;//赛季

    @Column(name = "teamname",nullable = false)
    private String teamname;//球队名称

    @Column(name = "winnum",nullable = false)
    private Integer winnum;//胜场数

    @Column(name = "lossnum",nullable = false)
    private Integer lossnum;//负场数

    @Column(name = "drawnum",nullable = false)
    private Integer drawnum;//平场数

    @Column(name = "goaldiff",nullable = false)
    private Integer goaldiff;//净胜球 

    @Column(name = "goals",nullable = false)
    private Integer goals;//得球数

    @Column(name = "redcard",nullable = false)
    private Integer redcard;//红牌数

    @Column(name = "yellowcard",nullable = false)
    private Integer yellowcard;//黄牌数

    @Column(name = "score",nullable = false)
    private Integer score;//总积分

    public TeamResult() {
        winnum = 0;
        lossnum = 0;
        drawnum = 0;
        goaldiff = 0;
        goals = 0;
        redcard = 0;
        yellowcard = 0;
        score = 0;
    }
}
