package com.example.csl.Domain;

import javax.persistence.*;
import lombok.*;

@Data
@Entity
@Table(name = "coach")
public class Coach {
    @Id
    @Column(name = "coachID",nullable = false)
    private String coachID;//教练编号

    @Column(name = "IDnum",nullable = false)
    private String IDnum;//身份证号

    @Column(name = "name",nullable = false)
    private String name;//姓名

    @Column(name = "birthday",nullable = false)
    private String birthday;//出生日期

    @Column(name = "origin",nullable = false)
    private String origin;//籍贯

    @Column(name = "teamID")
    private String teamID;//球队编号

    @Column(name = "teamname")
    private String teamname;//球队名称
}
