package com.example.csl.Domain;

import javax.persistence.*;
import lombok.*;

@Data
@Entity
@Table(name = "schedule")
public class Schedule {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "num",nullable = false)
    private Integer num;//序号

    @Column(name = "season",nullable = false)
    private Integer season;//赛季

    @Column(name = "gamedate",nullable = false)
    private String gamedate;//比赛日期

    @Column(name = "gametime",nullable = false)
    private String gametime;//比赛时间
    
    @Column(name = "gamecity",nullable = false)
    private String gamecity;//比赛城市

    @Column(name = "gameID",nullable = false)
    private String gameID;//比赛编号

    @Column(name = "hometeamID",nullable = false)
    private String hometeamID;//主场球队编号

    @Column(name = "hometeamname",nullable = false)
    private String hometeamname;//主场球队名称

    @Column(name = "guestteamID",nullable = false)
    private String guestteamID;//客场球队编号

    @Column(name = "guestteamname",nullable = false)
    private String guestteamname;//客场球队名称

    @Column(name = "hometeam",nullable = false)
    private String hometeam;//主场球队球员教练

    @Column(name = "guestteam",nullable = false)
    private String guestteam;//客场球队球员教练
    
    @Column(name = "score",nullable = false)
    private String score;//比分
}
