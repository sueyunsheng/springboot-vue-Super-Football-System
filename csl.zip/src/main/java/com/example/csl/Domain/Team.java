package com.example.csl.Domain;

import javax.persistence.*;
import lombok.*;

@Data
@Entity
@Table(name = "team")
public class Team {
    @Id
    @Column(name = "teamID",nullable = false)
    private String teamID;//球队编号

    @Column(name = "teamname",nullable = false)
    private String teamname;//球队名称

    @Column(name = "foundedtime",nullable = false)
    private String foundedtime;//成立时间

    @Column(name = "homecity",nullable = false)
    private String homecity;//主场城市

    @Column(name = "level",nullable = false)
    private char level;//是否为中超球队
}