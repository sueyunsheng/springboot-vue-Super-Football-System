package com.example.csl.Domain;

import javax.persistence.*;
import lombok.*;

@Data
@Entity
@Table(name = "playerchange")
public class PlayerChange {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "num",nullable = false)
    private Integer num;//序号

    @Column(name = "time",nullable = false)
    private String time;//时间

    @Column(name = "playerID",nullable = false)
    private String playerId;//球员编号

    @Column(name = "nowteamID")
    private String nowteamID;//现球队编号

    @Column(name = "nowteamname")
    private String nowteamname;//球队名称

    @Column(name = "originalteamID")
    private String originalteamID;//原球队编号

    @Column(name = "originalteamname")
    private String originalteamname;//球队名称
}
