package com.example.csl.Domain;

import javax.persistence.*;
import lombok.*;

@Data
@Entity
@Table(name = "overview")
public class Overview {
    @Id
    @Column(name = "season",nullable = false)
    private Integer season;//赛季

    @Column(name = "starttime",nullable = false)
    private String starttime;//开始时间

    @Column(name = "endtime",nullable = false)
    private String endtime;//结束时间
    

    @Column(name = "ranking",nullable = false)
    private String ranking;//排名
}
