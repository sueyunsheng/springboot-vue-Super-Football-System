package com.example.csl.Domain;

import javax.persistence.*;
import lombok.*;

@Data
@Entity
@Table(name = "strokeanalysis")
public class StrokeAnalysis {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "num",nullable = false)
    private Integer num;//序号

    @Column(name = "gameID",nullable = false)
    private String gameID;//比赛编号

    @Column(name = "timetoevent",nullable = false)
    private String timetoevent;//事件发生时间

    @Column(name = "event",nullable = false)
    private String event;//事件

    @Column(name = "teamID",nullable = false)
    private String teamID;//球队编号

    @Column(name = "playerID",nullable = false)
    private String playerId;//球员编号
}
