package com.example.csl.Domain;

import javax.persistence.*;
import lombok.*;

@Data
@Entity
@Table(name = "servicerela")
public class ServiceRela {
    @Id
    @Column(name = "teamID",nullable = false)
    private String teamID;//球队编号

    @Column(name = "teamname",nullable = false)
    private String teamname;//球队名称

    @Column(name = "players",nullable = false)
    private String players;//球员

    @Column(name = "coachs",nullable = false)
    private String coachs;//教练

    public ServiceRela() {
        players = "Player:";
        coachs = "Coach:";
    }
}
