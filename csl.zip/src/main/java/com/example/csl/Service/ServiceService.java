package com.example.csl.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;

import com.example.csl.Dao.*;
import com.example.csl.Domain.*;

@Service
public class ServiceService {
    @Autowired
    private ServiceRelaDao serviceDao;

    public void save(ServiceRela serviceRela) {
        serviceDao.save(serviceRela);
    }

    public List<ServiceRela> serviceList() {
        return serviceDao.findAll();
    }

    public ServiceRela service(String teamID) {
        return serviceDao.getById(teamID);
    }
}