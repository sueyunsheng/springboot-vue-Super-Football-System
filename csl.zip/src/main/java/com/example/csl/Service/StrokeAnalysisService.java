package com.example.csl.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;

import com.example.csl.Dao.*;
import com.example.csl.Domain.*;

@Service
public class StrokeAnalysisService {
    @Autowired
    private StrokeAnalysisDao strokeAnalysisDao;

    public void save(StrokeAnalysis strokeAnalysis) {
    strokeAnalysisDao.save(strokeAnalysis);
    }

    public List<StrokeAnalysis> eventList() {
        return strokeAnalysisDao.findAll();
    }
}
