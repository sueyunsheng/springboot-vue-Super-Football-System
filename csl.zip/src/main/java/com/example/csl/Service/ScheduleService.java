package com.example.csl.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;

import com.example.csl.Dao.*;
import com.example.csl.Domain.*;

@Service
public class ScheduleService {
    @Autowired
    private ScheduleDao scheduleDao;

    public void save(Schedule schedule) {
        scheduleDao.save(schedule);
    }

    public List<Schedule> scheduleList() {
        return scheduleDao.findAll();
    }

    public Schedule getByID(String gameID) {
        for(Schedule sche:scheduleDao.findAll()) {
            if((sche.getGameID()).equals(gameID))
                return sche;
        }
        return new Schedule();
    }
}
