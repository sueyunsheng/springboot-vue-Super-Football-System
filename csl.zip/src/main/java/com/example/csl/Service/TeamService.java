package com.example.csl.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;

import com.example.csl.Dao.*;
import com.example.csl.Domain.*;

@Service
public class TeamService {
    @Autowired
    private TeamDao teamDao;

    public void save(Team team) {
		teamDao.save(team);
	}

    public List<Team> teamList() {
        return teamDao.findAll();
    }

    public String getID(String teamname) {
        for(Team team:teamDao.findAll()) {
            if(team.getTeamname().equals(teamname))
                return team.getTeamID();
        }
        return "doesn't exit!";
    }

    public String getCity(String teamname) {
        for(Team team:teamDao.findAll()) {
            if(team.getTeamname().equals(teamname))
                return team.getHomecity();
        }
        return "doesn't exit!";
    }

    public String getName(String teamID) {
        Team team = teamDao.getById(teamID);
        return team.getTeamname();
    }

    public Team team(String teamID) {
        return teamDao.getById(teamID);
    }
}
