package com.example.csl.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;

import com.example.csl.Dao.*;
import com.example.csl.Domain.*;

@Service
public class PlayerService {
    @Autowired
    private PlayerDao playerDao;

    public void save(Player player) {
		playerDao.save(player);
	}

    public List<Player> playerList() {
        return playerDao.findAll();
    }

    public Player getById(String playerId) {
        return playerDao.getById(playerId);
    }

    public String getNmae(String playerId) {
        Player player = playerDao.getById(playerId);
        return player.getName();
    }

    public String getTeamID(String playerId) {
        Player player = playerDao.getById(playerId);
        return player.getTeamID();
    }
}
