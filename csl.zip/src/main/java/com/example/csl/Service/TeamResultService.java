package com.example.csl.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;

import com.example.csl.Dao.*;
import com.example.csl.Domain.*;

@Service
public class TeamResultService {
    @Autowired
    private TeamResultDao resultDao;

    public void save(TeamResult teamResult) {
        resultDao.save(teamResult);
    }

    public void getResult(String teamID,String event,Integer gd,Integer g,Integer r,Integer y) {
        TeamResult result = resultDao.getById(teamID);
        result.setGoaldiff(result.getGoaldiff() + gd);
        result.setGoals(result.getGoals() + g);
        result.setRedcard(result.getRedcard() + r);
        result.setYellowcard(result.getYellowcard() + y);
        if(event.equals("win")) {
            result.setScore(result.getScore() + 3);
            result.setWinnum(result.getWinnum() + 1);
        }
        else if(event.equals("draw")) {
            result.setScore(result.getScore() + 1);
            result.setDrawnum(result.getDrawnum() + 1);
        }
        else
            result.setLossnum(result.getLossnum() + 1);
        resultDao.save(result);
    }

    public List<TeamResult> resultList() {
        return resultDao.findAll();
    }
}
