package com.example.csl.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;

import com.example.csl.Dao.*;
import com.example.csl.Domain.*;

@Service
public class CoachService {
    @Autowired
    private CoachDao coachDao;

    public void save(Coach coach) {
		coachDao.save(coach);
	}

    public List<Coach> coachList() {
        return coachDao.findAll();
    }

    public Coach getById(String coachID) {
        return coachDao.getById(coachID);
    }
}
