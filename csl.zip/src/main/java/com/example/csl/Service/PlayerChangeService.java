package com.example.csl.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;

import com.example.csl.Dao.*;
import com.example.csl.Domain.*;

@Service
public class PlayerChangeService {
    @Autowired
    PlayerChangeDao changeDao;

    public void save(PlayerChange change) {
        changeDao.save(change);
    }

    public List<PlayerChange> changeList(String playerId) {
        List<PlayerChange> allchanges = changeDao.findAll();
        List<PlayerChange> changes = new ArrayList<PlayerChange>();
        for(PlayerChange change:allchanges) {
            if(change.getPlayerId().equals(playerId) && change.getNowteamID()!=null)
                changes.add(change);
        }
        Collections.sort(changes, new Comparator<PlayerChange>() {
            @Override
            public int compare(PlayerChange c1, PlayerChange c2) {
                return c1.getNum() - c2.getNum();
            }
        });
        return changes;
    }
}
