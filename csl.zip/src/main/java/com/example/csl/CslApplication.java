package com.example.csl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CslApplication {

	public static void main(String[] args) {
		SpringApplication.run(CslApplication.class, args);
	}

}
