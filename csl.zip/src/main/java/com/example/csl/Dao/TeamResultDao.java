package com.example.csl.Dao;

import com.example.csl.Domain.*;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TeamResultDao extends JpaRepository<TeamResult,String> {  
}
