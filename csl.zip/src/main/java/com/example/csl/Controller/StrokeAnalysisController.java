package com.example.csl.Controller;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RequestParam;
import com.alibaba.fastjson.*;
import com.example.csl.Service.*;
import com.example.csl.Domain.*;
import java.util.*;
import lombok.*;

@RestController
@RequestMapping("/game")
@CrossOrigin
public class StrokeAnalysisController {
    @Autowired
    StrokeAnalysisService gameService;

    @Autowired
    PlayerService playerService;

    @Autowired
    ScheduleService scheduleService;

    @Autowired
    TeamService teamService;

    @Autowired
    TeamResultService resultService;

    @PostMapping("/save")
    public String saveGame(@RequestBody JSONObject param) {
        try {
            Map<String,Statistic> sta = new HashMap<>();
            JSONArray events = param.getJSONArray("newfield");
            String gameID= param.getString("gameID");
            Schedule sche = scheduleService.getByID(gameID);
            if(sche.getGameID() == null) 
                return "该比赛不存在";
            String homeID = sche.getHometeamID();
            String guestID = sche.getGuestteamID();
            Statistic home = new Statistic();
            Statistic guest = new Statistic();
            int len = events.size();
            for(int i=0;i<len;i++) { 
                String playerId = events.getJSONObject(i).getString("player");
                String timetoevent = events.getJSONObject(i).getString("time");
                String event = events.getJSONObject(i).getString("eve");
                String teamID = playerService.getTeamID(playerId);
                StrokeAnalysis game = new StrokeAnalysis();
                game.setGameID(gameID);
                game.setPlayerId(playerId);
                game.setTimetoevent(timetoevent);
                game.setTeamID(teamID);
                if(!sta.containsKey(playerId))
                    sta.put(playerId, new Statistic());
                Statistic tmp = sta.get(playerId);
                if(event.equals("红牌")) {
                    tmp.red++;
                    if(teamID.equals(homeID)) 
                        home.red++;
                    else
                        guest.red++;
                }
                else if(event.equals("黄牌")) 
                    if(tmp.yellow == 1) {
                        event = "双黄牌变红牌";
                        tmp.red++;
                        tmp.yellow--;
                        if(teamID.equals(homeID)) {
                            home.red++;
                            home.yellow--;
                        }
                        else {
                            guest.red++;
                            guest.yellow--;
                        }
                    }
                    else {
                        tmp.yellow++;
                        if(teamID.equals(homeID)) 
                            home.yellow++;
                        else
                            guest.yellow++;
                    } 
                else {
                    tmp.shoot++;
                    if(teamID.equals(homeID)) 
                        home.shoot++;
                    else
                        guest.shoot++;
                }
                game.setEvent(event);
                gameService.save(game);
            }
            for(Map.Entry<String,Statistic> map : sta.entrySet()) {//更新射手生涯数据
                Player player = playerService.getById(map.getKey());
                player.setRednum(player.getRednum() + map.getValue().red);
                player.setYelnum(player.getYelnum() + map.getValue().yellow);
                player.setShootnum(player.getShootnum() + map.getValue().shoot);
                playerService.save(player);
            }
            sche.setScore(String.valueOf(home.shoot) + '/' + String.valueOf(guest.shoot));
            scheduleService.save(sche);
            if(home.shoot>guest.shoot) {
                resultService.getResult(homeID, "win", home.shoot-guest.shoot, home.shoot, home.red, home.yellow);
                resultService.getResult(guestID, "loss", 0, guest.shoot, guest.red, guest.yellow);
            }
            else if(home.shoot==guest.shoot) {
                resultService.getResult(homeID, "draw", 0, home.shoot, home.red, home.yellow);
                resultService.getResult(guestID, "draw", 0, guest.shoot, guest.red, guest.yellow);
            }
            else {
                resultService.getResult(homeID, "loss", 0, home.shoot, home.red, home.yellow);
                resultService.getResult(guestID, "win", guest.shoot-home.shoot, guest.shoot, guest.red, guest.yellow);
            }
            return "录入成功";
        } catch(Exception e) {
            return "录入失败";
        }
    }

    @ResponseBody
    @RequestMapping("/show")
    public  List<Event> showEvent(@RequestParam("gameID") String gameID) {
        List<StrokeAnalysis> gameList = gameService.eventList();
        List<Event> eventList = new ArrayList<Event>();
        for(StrokeAnalysis event:gameList) {
            if(event.getGameID().equals(gameID)) {
                Event e = new Event(event.getTimetoevent(),
                                    event.getEvent(),
                                    teamService.getName(event.getTeamID()),
                                    playerService.getNmae(event.getPlayerId()));
                eventList.add(e);
            }
        }
        Collections.sort(eventList);
        return eventList;
    }
}

class Statistic {
    int yellow;
    int red;
    int shoot;
    public Statistic() {
        yellow = 0;
        red = 0;
        shoot = 0;
    }
}

@Data
class Event implements Comparable<Event> {
    String timetoevent;
    String event;
    String teamname;
    String player;
    public Event(String time,String eve,String team,String name) {
        timetoevent = time;
        event =eve;
        teamname = team;
        player = name;
    }
    @Override
    public int compareTo(Event event) {
        return this.timetoevent.compareTo(event.getTimetoevent());
    }
}
