package com.example.csl.Controller;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.CrossOrigin;
import com.example.csl.Service.*;
import com.alibaba.fastjson.JSON;
import com.example.csl.Domain.*;
import java.util.*;

@RestController
@RequestMapping("/team")
@CrossOrigin
public class TeamController {
    @Autowired
    TeamService teamService;

    @Autowired
    TeamResultService resultService;

    @Autowired
    ServiceService service;

    @GetMapping("/save")
    public String registTeam(@RequestParam("teamname") String teamname,
                        @RequestParam("foundedtime") String foundedtime,
                        @RequestParam("homecity") String homecity) {
        try {
            String teamID = foundedtime.split("-")[0] + foundedtime.split("-")[1];
            List<Team> teams = teamService.teamList();
            int count = 0;
            for(Team team : teams) {
                if(team.getTeamID().substring(0, 6).equals(teamID)) count++;
            }
            teamID += String.format("%04d",count);
            char level = 'y';
            Team team = new Team();
            team.setFoundedtime(foundedtime);
            team.setLevel(level);
            team.setHomecity(homecity);
            team.setTeamID(teamID);
            team.setTeamname(teamname);
            teamService.save(team);
            TeamResult teamResult = new TeamResult();
            teamResult.setSeason(1);
            teamResult.setTeamID(teamID);
            teamResult.setTeamname(teamname);
            resultService.save(teamResult);
            ServiceRela rela = new ServiceRela();
            rela.setTeamID(teamID);
            rela.setTeamname(teamname);
            service.save(rela);
            return "注册成功！球队编号为：" + teamID;
        } catch(Exception e) {
            return "注册失败";
        }
    }
    
    @ResponseBody
    @RequestMapping("/display")
    public List<Team> showTeam() {
        List<Team> cslTeam = new ArrayList<Team>();
        for (Team team:teamService.teamList())  {
            if(team.getLevel() == 'y') 
                cslTeam.add(team);
        }
        return cslTeam;
    }

    @ResponseBody
    @RequestMapping("/showone")
    public String showOneTeam(@RequestParam("teamID") String teamID) {
        return JSON.toJSONString(teamService.team(teamID));
    }
}
