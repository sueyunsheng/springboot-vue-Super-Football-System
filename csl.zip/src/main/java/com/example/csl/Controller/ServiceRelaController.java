package com.example.csl.Controller;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
//import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.CrossOrigin;
import com.example.csl.Service.*;
//import com.alibaba.fastjson.*;
//import com.example.csl.Domain.*;
//import java.util.*;

@RestController
@RequestMapping("/service")
@CrossOrigin
public class ServiceRelaController {
    @Autowired
    ServiceService service;

    @Autowired
    TeamService teamService;

}
