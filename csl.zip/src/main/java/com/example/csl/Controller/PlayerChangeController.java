package com.example.csl.Controller;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CrossOrigin;
import com.example.csl.Service.*;
import com.example.csl.Domain.*;
import java.util.*;

@RestController
@RequestMapping("/change")
@CrossOrigin
public class PlayerChangeController {
    @Autowired
    PlayerChangeService changeService;

    @GetMapping("/record")
    public List<PlayerChange> getChangeRecord(@RequestParam("playerId") String playerId) {
        System.out.println(changeService.changeList(playerId));
        return changeService.changeList(playerId);
    }
}
