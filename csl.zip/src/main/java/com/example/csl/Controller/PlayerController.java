package com.example.csl.Controller;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.CrossOrigin;
import com.example.csl.Service.*;
import com.alibaba.fastjson.JSON;
import com.example.csl.Domain.*;
import java.util.*;

@RestController
@RequestMapping("/player")
@CrossOrigin
public class PlayerController {
    @Autowired
    PlayerService playerService;

    @Autowired
    TeamService teamService;

    @Autowired
    ServiceService service;

    @Autowired
    PlayerChangeService changeService;

    @GetMapping("/save")
    public String registPlayer(@RequestParam("name") String name,
                        @RequestParam("IDnum") String IDnum,
                        @RequestParam("birthday") String birthday,
                        @RequestParam("origin") String origin,
                        @RequestParam("height") String height,
                        @RequestParam("weight") String weight) {
        try {
            Calendar cal=Calendar.getInstance();  
            String playerId = String.format("%04d",cal.get(Calendar.YEAR)) + String.format("%02d",cal.get(Calendar.MONTH));
            List<Player> players = playerService.playerList();
            int count = 0;
            for(Player player : players) {
                if(player.getPlayerId().substring(0, 6).equals(playerId)) count++;
            }
            playerId += String.format("%04d",count);
            Player player = new Player();
            player.setPlayerId(playerId);
            player.setName(name);
            player.setIDnum(IDnum);
            player.setBirthday(birthday);
            player.setOrigin(origin);
            if(!height.matches("[0-9]+")) 
                return "身高格式错误";
            if(!weight.matches("[0-9]+"))
                return "体重格式错误";
            player.setHeight(Integer.parseInt(height));
            player.setWeight(Integer.parseInt (weight));
            player.setShootnum(0);
            System.out.println(player);
            playerService.save(player);
            PlayerChange change = new PlayerChange();
            change.setPlayerId(playerId);
            change.setTime(String.format("%04d",cal.get(Calendar.YEAR)) + '-' +
                            String.format("%02d",cal.get(Calendar.MONTH)) + '-' +
                            String.format("%02d",cal.get(Calendar.DAY_OF_MONTH)));
            changeService.save(change);
            return "注册成功！您的球员编号为:" + playerId;
        } catch(Exception e) {
            return "注册失败";
        }
    }

    @GetMapping("/apply")
    public String applyTeam(@RequestParam("playerId") String playerId,
                        @RequestParam("teamname") String teamname,
                        @RequestParam("position") String position) {
        try {
            Calendar cal=Calendar.getInstance();
            Player player = playerService.getById(playerId);
            String teamID = teamService.getID(teamname);
            if(teamID=="doesn't exit!")
                return "该球队不存在";
            PlayerChange change = new PlayerChange();
            change.setPlayerId(playerId);
            change.setTime(String.format("%04d",cal.get(Calendar.YEAR)) + '-' +
                            String.format("%02d",cal.get(Calendar.MONTH)) + '-' +
                            String.format("%02d",cal.get(Calendar.DAY_OF_MONTH)));
            change.setOriginalteamID(player.getTeamID());
            change.setOriginalteamname(player.getTeamname());
            change.setNowteamID(teamID);
            change.setNowteamname(teamname);
            changeService.save(change);
            player.setTeamID(teamID);
            player.setTeamname(teamname);
            player.setPosition(position);
            playerService.save(player);
            ServiceRela rela = service.service(teamID);
            String newPlayers = rela.getPlayers() + " " + player.getName();
            rela.setPlayers(newPlayers);
            service.save(rela);
            return "申请成功";
        } catch(Exception e) {
            return "申请失败";
        }
    }

    @GetMapping("/teammember")
    public List<Player> getTeamMem(@RequestParam("teamID") String teamID) {
        List<Player> players = playerService.playerList();
        List<Player> teammem = new ArrayList<Player>();
        for(Player player:players) {
            if(player.getTeamID() != null && player.getTeamID().equals(teamID))
                teammem.add(player);
        }
        return teammem;
    }

    @ResponseBody
    @RequestMapping("/display")
    public List<Player> displayPlayer() {
        return playerService.playerList();
    }

    @ResponseBody
    @RequestMapping("/topten")
    public List<Player> toptenPlayer() {
        List<Player> players = playerService.playerList();
        Collections.sort(players, new Comparator<Player>() {
            @Override
            public int compare(Player p1, Player p2) {
                return p2.getShootnum() - p1.getShootnum();
            }
        });
        if(players.size() <= 10)
            return players;
        else
            return players.subList(0, 10);
    }

    @ResponseBody
    @RequestMapping("/showone")
    public String showOnePlayer(@RequestParam("playerID") String playerID) {
        Player player = playerService.getById(playerID);
        return JSON.toJSONString(player);
    }
}
