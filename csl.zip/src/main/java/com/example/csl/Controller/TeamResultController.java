package com.example.csl.Controller;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.CrossOrigin;
import com.example.csl.Service.*;
import com.example.csl.Domain.*;
import java.util.*;
import lombok.*;

@RestController
@RequestMapping("/result")
@CrossOrigin
public class TeamResultController {
    @Autowired
    TeamResultService resultService;

    @ResponseBody
    @RequestMapping("/display")
    public List<TeamResult> displayResults() {
        List<TeamResult> results = resultService.resultList();
        Collections.sort(results, new Comparator<TeamResult>() {
            @Override
            public int compare(TeamResult t1, TeamResult t2) {
                if(t1.getScore()!=t2.getScore()) 
                    return t2.getScore() - t1.getScore();
                else if(t2.getGoaldiff() != t1.getGoaldiff())
                    return t2.getGoaldiff() - t1.getGoaldiff();
                else 
                    return t2.getGoals() - t1.getGoals();
            }
        });
        return results;
    }

    @ResponseBody
    @RequestMapping("/minidisplay")
    public List<MiniScoreTable> displayMiniResults() {
        List<TeamResult> results = resultService.resultList();
        Collections.sort(results, new Comparator<TeamResult>() {
            @Override
            public int compare(TeamResult t1, TeamResult t2) {
                if(t1.getScore()!=t2.getScore()) 
                    return t2.getScore() - t1.getScore();
                else if(t2.getGoaldiff() != t1.getGoaldiff())
                    return t2.getGoaldiff() - t1.getGoaldiff();
                else 
                    return t2.getGoals() - t1.getGoals();
            }
        });
        List<MiniScoreTable> mini = new ArrayList<MiniScoreTable>();
        for(TeamResult result:results) {
            mini.add(new MiniScoreTable(result.getTeamname(),
                                        String.valueOf(result.getWinnum()) + '/' + String.valueOf(result.getDrawnum()) 
                                        + '/' + String.valueOf(result.getLossnum()),
                                        result.getScore() ));
        }
        return mini;
    }
}

@Data
class MiniScoreTable {
    String name;
    String s_p_f;
    Integer score;
    public MiniScoreTable(String n,String spf,Integer s) {
        name = n;
        s_p_f = spf;
        score = s;
    }
}
