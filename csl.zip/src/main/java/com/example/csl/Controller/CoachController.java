package com.example.csl.Controller;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.CrossOrigin;
import com.example.csl.Service.*;
import com.example.csl.Domain.*;
import java.util.*;

@RestController
@RequestMapping("/coach")
@CrossOrigin
public class CoachController {
    @Autowired
    CoachService coachService;

    @Autowired
    TeamService teamService;

    @GetMapping("/save")
    public String registCoach(@RequestParam("name") String name,
                        @RequestParam("IDnum") String IDnum,
                        @RequestParam("birthday") String birthday,
                        @RequestParam("origin") String origin) {
        try {
            Calendar cal=Calendar.getInstance();  
            String coachID = String.format("%04d",cal.get(Calendar.YEAR)) + String.format("%02d",cal.get(Calendar.MONTH));
            List<Coach> coachs = coachService.coachList();
            int count = 0;
            for(Coach coach : coachs) {
                if(coach.getCoachID().substring(0, 6).equals(coachID)) count++;
            }
            coachID += String.format("%04d",count);
            Coach coach = new Coach();
            coach.setCoachID(coachID);;
            coach.setName(name);
            coach.setIDnum(IDnum);
            coach.setBirthday(birthday);
            coach.setOrigin(origin);
            coachService.save(coach);
            return "注册成功！您的教练编号为：" + coachID;
        } catch(Exception e) {
            return "注册失败";
        }
    }

    @GetMapping("/teammember")
    public List<Coach> getTeamMem(@RequestParam("teamID") String teamID) {
        List<Coach> coachs = coachService.coachList();
        List<Coach> teammem = new ArrayList<Coach>();
        for(Coach coach:coachs) {
            if(coach.getTeamID() != null && coach.getTeamID().equals(teamID))
                teammem.add(coach);
        }
        return teammem;
    }

    @ResponseBody
    @RequestMapping("/display")
    public List<Coach> displayCoach() {
        return coachService.coachList();
    }

    @GetMapping("/apply")
    public String applyTeam(@RequestParam("coachID") String coachID,
                        @RequestParam("teamname") String teamname) {
        try {
            Coach coach = coachService.getById(coachID);
            String teamID = teamService.getID(teamname);
            if(teamID == "doesn't exit!")
                return "该球队不存在";
            coach.setTeamID(teamID);
            coach.setTeamname(teamname);
            System.out.println(coach);
            coachService.save(coach);
            return "申请成功";
        } catch(Exception e) {
            return "申请失败";
        }
    }
}