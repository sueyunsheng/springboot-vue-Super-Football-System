package com.example.csl.Controller;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.CrossOrigin;
import com.example.csl.Service.*;
import com.example.csl.Domain.*;
import java.util.*;

@RestController
@RequestMapping("/schedule")
@CrossOrigin
public class ScheduleController {
    @Autowired
    ScheduleService scheduleService;

    @Autowired
    TeamService teamService;

    @Autowired
    ServiceService service;

    @GetMapping("/insert")
    public String insertSchedule(@RequestParam("gamedate") String gamedate,
                                @RequestParam("gametime") String gametime,
                                @RequestParam("hometeam") String hometeam,
                                @RequestParam("guestteam") String guestteam) {
        try {
            System.out.println("hello");
            String gamecity = teamService.getCity(hometeam);
            String gameID = gamedate.split("-")[0] + gamedate.split("-")[1];
            int count = 0;
            List<Schedule> schedulelist = scheduleService.scheduleList();
            for(Schedule schedule : schedulelist) {
                if(schedule.getGameID().substring(0, 6).equals(gameID)) count++;
            }
            gameID += String.format("%04d",count);
            String hometeamID = teamService.getID(hometeam),guestteamID =teamService.getID(guestteam);
            if(hometeamID == "doesn't exit!" || guestteamID == "doesn't exit!")
                return "队伍不存在！";
            Schedule schedule = new Schedule();
            schedule.setGamedate(gamedate);
            schedule.setGamecity(gamecity);
            schedule.setGametime(gametime);
            schedule.setHometeamname(hometeam);
            schedule.setGuestteamname(guestteam);
            schedule.setHometeamID(hometeamID);
            schedule.setGuestteamID(guestteamID);
            schedule.setSeason(1);
            schedule.setScore("-/-");
            schedule.setGameID(gameID);
            System.out.println(schedule);
            String homemem = service.service(hometeamID).getPlayers() + '\n' + service.service(hometeamID).getCoachs();
            String guestmem = service.service(guestteamID).getPlayers() + '\n' + service.service(guestteamID).getCoachs();;
            schedule.setHometeam(homemem);
            schedule.setGuestteam(guestmem);
            scheduleService.save(schedule);
            return "比赛录入成功";
        } catch(Exception e) {
            return "比赛录入失败";
        }
    }

    @ResponseBody
    @RequestMapping("/display")
    public List<Schedule> displaySchedule() {
        return scheduleService.scheduleList();
    }
}
